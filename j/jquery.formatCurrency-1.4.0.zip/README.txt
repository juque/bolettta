jQuery formatCurrency Plugin

For more information see the WIKI at http://jquery-formatcurrency.googlecode.com